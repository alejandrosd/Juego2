package presentacion.modelo;

import presentacion.vistas.EngineersView;
import presentacion.vistas.PrincipalView;

/**
 *
 * @author David Bohorquez
 */
public class Game {

    private PrincipalView ventanaPrincipal;
    private EngineersView ventanaPersonajes;

    public Game() {

    }

    public void iniciar() {
        getVentanaPrincipal().setVisible(true);
    }

    public PrincipalView getVentanaPrincipal() {
        if (ventanaPrincipal == null) {
            ventanaPrincipal = new PrincipalView(this);
        }

        return ventanaPrincipal;
    }

    public EngineersView getVentanaPersonajes() {
        if(ventanaPersonajes == null) {
            ventanaPersonajes = new EngineersView(this);
        }
        return ventanaPersonajes;
    }
    
    

}
