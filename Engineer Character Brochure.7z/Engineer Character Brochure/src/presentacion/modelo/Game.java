package presentacion.modelo;

import logica.abstractfactory.factories.AbstractFactory;
import logica.abstractfactory.factories.CivilEngineerFactory;
import logica.abstractfactory.factories.ElectricalEngineerFactory;
import logica.abstractfactory.factories.SoftwareEngineerFactory;
import logica.abstractfactory.products.Clothe;
import logica.abstractfactory.products.Tool;
import logica.abstractfactory.products.Vehicle;
import presentacion.vistas.EngineerFactoryView;
import presentacion.vistas.EngineerView;
import presentacion.vistas.PrincipalView;

/**
 *
 * @author David Bohorquez
 */
public class Game {

    private AbstractFactory factory;
    private Tool tool;
    private Clothe clothe;
    private Vehicle vehicle;

    private PrincipalView ventanaPrincipal;
    private EngineerFactoryView ventanaEngFactory;
    private EngineerView ventanaEng;

    public Game() {

    }

    public void iniciar() {
        getVentanaPrincipal().setVisible(true);
    }

    public /*AbstractFactory*/ void chooseFactory(int i) {
        switch (i) {
            case 0:
                factory = new SoftwareEngineerFactory();
                break;
            case 1:
                factory = new ElectricalEngineerFactory();
                break;
            default:
                factory = new CivilEngineerFactory();
                break;
        }
        //return factory;
    }

    public void createEngineer() {
        tool = factory.createTool();
        clothe = factory.createClothe();
        vehicle = factory.createVehicle();
    }

    public int check(boolean[] states) {
        for (int i = 0; i < 3; i++) {
            if (states[i] == true) {
                return i;
            }
        }
        return -1;
    }

    public void selectEngineer(int i) {
        ventanaEngFactory.initStates();

        ventanaEngFactory.getImgStates()[i] = true;
    }

    public PrincipalView getVentanaPrincipal() {
        if (ventanaPrincipal == null) {
            ventanaPrincipal = new PrincipalView(this);
        }

        return ventanaPrincipal;
    }

    public EngineerFactoryView getVentanaEngFactory() {
        if (ventanaEngFactory == null) {
            ventanaEngFactory = new EngineerFactoryView(this);
        }
        return ventanaEngFactory;
    }

    public EngineerView getVentanaEng() {
        if(ventanaEng == null) {
            ventanaEng = new EngineerView(this);
        }
        return ventanaEng;
    }

}
