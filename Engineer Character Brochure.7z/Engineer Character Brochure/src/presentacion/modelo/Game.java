package presentacion.modelo;

import presentacion.vistas.PrincipalView;

/**
 *
 * @author David Bohorquez
 */
public class Game {

    private PrincipalView ventanaPrincipal;

    public Game() {

    }

    public void iniciar() {
        getVentanaPrincipal().setVisible(true);
    }

    public PrincipalView getVentanaPrincipal() {
        if (ventanaPrincipal == null) {
            ventanaPrincipal = new PrincipalView(this);
        }

        return ventanaPrincipal;
    }

}
