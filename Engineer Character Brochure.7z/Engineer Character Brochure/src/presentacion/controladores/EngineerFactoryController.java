package presentacion.controladores;

import java.awt.Cursor;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import presentacion.modelo.Game;
import presentacion.vistas.EngineerFactoryView;
import presentacion.vistas.PrincipalView;

/**
 *
 * @author David Bohorquez
 */
public class EngineerFactoryController implements MouseListener {

    private EngineerFactoryView ventanaEngFactory;

    public EngineerFactoryController(EngineerFactoryView ventana) {
        ventanaEngFactory = ventana;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        Game modelo = ventanaEngFactory.getModelo();
        JLabel background = ventanaEngFactory.getLblBackground();
        boolean[] states = ventanaEngFactory.getImgStates();

        if (e.getSource().equals(ventanaEngFactory.getLblClose())) {
            System.exit(0);
        } else if (e.getSource().equals(ventanaEngFactory.getLblBack())) {
            modelo.getVentanaEngFactory().setVisible(false);
            modelo.getVentanaPrincipal().setVisible(true);

        }

        if (e.getSource().equals(ventanaEngFactory.getLblSoftware())) {
            if (modelo.check(states) != 0) {
                modelo.selectEngineer(0);
                background.setIcon(ventanaEngFactory.getImgSoftCreate());
            }
        } else if (e.getSource().equals(ventanaEngFactory.getLblElectrical())) {
            if (modelo.check(states) != 1) {
                modelo.selectEngineer(1);
                background.setIcon(ventanaEngFactory.getImgElectCreate());
            }
        } else if (e.getSource().equals(ventanaEngFactory.getLblCivil())) {
            if (modelo.check(states) != 2) {
                modelo.selectEngineer(2);
                background.setIcon(ventanaEngFactory.getImgCivilCreate());
            }
        } else if (e.getSource().equals(ventanaEngFactory.getLblBackground())) {
            ventanaEngFactory.initStates();
            background.setIcon(ventanaEngFactory.getImgBase());
        } else if (e.getSource().equals(ventanaEngFactory.getLblCreate())) {
            modelo.getVentanaEngFactory().setVisible(false);
            modelo.getVentanaEng().setVisible(true);
        }

        System.out.println("Click");
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        Game modelo = ventanaEngFactory.getModelo();
        JLabel background = ventanaEngFactory.getLblBackground();
        boolean[] states = ventanaEngFactory.getImgStates();

        if ((e.getSource().equals(ventanaEngFactory.getLblClose()))
                || (e.getSource().equals(ventanaEngFactory.getLblBack()))) {

            ventanaEngFactory.setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        if (e.getSource().equals(ventanaEngFactory.getLblSoftware())) {
            if (modelo.check(states) != 0) {
                ventanaEngFactory.setCursor(new Cursor(Cursor.HAND_CURSOR));

                if (modelo.check(states) == -1) {
                    background.setIcon(ventanaEngFactory.getImgSoftware());

                } else if (modelo.check(states) == 1) {
                    background.setIcon(ventanaEngFactory.getImgElectSoft());
                } else if (modelo.check(states) == 2) {
                    background.setIcon(ventanaEngFactory.getImgCivilSoft());
                }
            } else {
                ventanaEngFactory.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }

        } else if (e.getSource().equals(ventanaEngFactory.getLblElectrical())) {
            if (modelo.check(states) != 1) {
                ventanaEngFactory.setCursor(new Cursor(Cursor.HAND_CURSOR));

                if (modelo.check(states) == -1) {
                    background.setIcon(ventanaEngFactory.getImgElectrical());

                } else if (modelo.check(states) == 0) {
                    background.setIcon(ventanaEngFactory.getImgSoftElect());
                } else if (modelo.check(states) == 2) {
                    background.setIcon(ventanaEngFactory.getImgCivilElect());
                }
            } else {
                ventanaEngFactory.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        } else if (e.getSource().equals(ventanaEngFactory.getLblCivil())) {
            if (modelo.check(states) != 2) {
                ventanaEngFactory.setCursor(new Cursor(Cursor.HAND_CURSOR));

                if (modelo.check(states) == -1) {
                    background.setIcon(ventanaEngFactory.getImgCivil());

                } else if (modelo.check(states) == 0) {
                    background.setIcon(ventanaEngFactory.getImgSoftCivil());
                } else if (modelo.check(states) == 1) {
                    background.setIcon(ventanaEngFactory.getImgElectCivil());
                }
            } else {
                ventanaEngFactory.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        } else if (e.getSource().equals(ventanaEngFactory.getLblCreate())) {
            if (modelo.check(states) != -1) {
                ventanaEngFactory.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
        Game modelo = ventanaEngFactory.getModelo();
        JLabel background = ventanaEngFactory.getLblBackground();
        boolean[] states = ventanaEngFactory.getImgStates();

        if ((e.getSource().equals(ventanaEngFactory.getLblClose()))
                || (e.getSource().equals(ventanaEngFactory.getLblBack())) || (e.getSource().equals(ventanaEngFactory.getLblSoftware()))
                || (e.getSource().equals(ventanaEngFactory.getLblElectrical()))
                || (e.getSource().equals(ventanaEngFactory.getLblCivil()))
                || (e.getSource().equals(ventanaEngFactory.getLblCreate()))) {

            ventanaEngFactory.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        }

        if (e.getSource().equals(ventanaEngFactory.getLblSoftware())) {
            if (modelo.check(states) != 0) {

                switch (modelo.check(states)) {
                    case 1:
                        background.setIcon(ventanaEngFactory.getImgElectCreate());
                        break;
                    case 2:
                        background.setIcon(ventanaEngFactory.getImgCivilCreate());
                        break;
                    default:
                        background.setIcon(ventanaEngFactory.getImgBase());
                        break;
                }

            }
        } else if (e.getSource().equals(ventanaEngFactory.getLblElectrical())) {
            if (modelo.check(states) != 1) {

                switch (modelo.check(states)) {
                    case 0:
                        background.setIcon(ventanaEngFactory.getImgSoftCreate());
                        break;
                    case 2:
                        background.setIcon(ventanaEngFactory.getImgCivilCreate());
                        break;
                    default:
                        background.setIcon(ventanaEngFactory.getImgBase());
                        break;
                }

            }
        } else if (e.getSource().equals(ventanaEngFactory.getLblCivil())) {
            if (modelo.check(states) != 2) {

                switch (modelo.check(states)) {
                    case 0:
                        background.setIcon(ventanaEngFactory.getImgSoftCreate());
                        break;
                    case 1:
                        background.setIcon(ventanaEngFactory.getImgElectCreate());
                        break;
                    default:
                        background.setIcon(ventanaEngFactory.getImgBase());
                        break;
                }

            }
        }
    }

}
