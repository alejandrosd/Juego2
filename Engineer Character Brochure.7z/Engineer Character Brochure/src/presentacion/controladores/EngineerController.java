package presentacion.controladores;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import presentacion.vistas.EngineerView;

/**
 *
 * @author David Bohorquez
 */
public class EngineerController implements MouseListener {

    private EngineerView ventanaEng;

    public EngineerController(EngineerView ventana) {
        ventanaEng = ventana;
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
