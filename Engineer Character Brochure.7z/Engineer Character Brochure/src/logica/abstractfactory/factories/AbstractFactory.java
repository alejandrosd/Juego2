package logica.abstractfactory.factories;

import logica.abstractfactory.products.Clothe;
import logica.abstractfactory.products.Tool;
import logica.abstractfactory.products.Vehicle;

/**
 *
 * @author David Bohorquez
 */
public interface AbstractFactory {
    
    public Clothe createBody();
    
    public Tool createWeapon();
    
    public Vehicle createVehicle();
}
