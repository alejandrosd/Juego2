package logica.abstractfactory.factories;

import logica.abstractfactory.products.Body;
import logica.abstractfactory.products.Weapon;

/**
 *
 * @author David Bohorquez
 */
public interface AbstractFactory {
    
    public Body createBody();
    
    public Weapon createWeapon();
}
