package logica.abstractfactory.factories;

import logica.abstractfactory.products.Body;
import logica.abstractfactory.products.SoftwareEngineerBody;
import logica.abstractfactory.products.SoftwareEngineerWeapon;
import logica.abstractfactory.products.Weapon;

/**
 *
 * @author David Bohorquez
 */
public class SoftwareEngineerFactory implements AbstractFactory {

    @Override
    public Body createBody() {
        return new SoftwareEngineerBody();
    }

    @Override
    public Weapon createWeapon() {
        return new SoftwareEngineerWeapon();
    }

}
