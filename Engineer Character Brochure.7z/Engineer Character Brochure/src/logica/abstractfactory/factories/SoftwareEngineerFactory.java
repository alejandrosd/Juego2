package logica.abstractfactory.factories;

import logica.abstractfactory.products.SoftwareEngineerClothe;
import logica.abstractfactory.products.SoftwareEngineerTool;
import logica.abstractfactory.products.Clothe;
import logica.abstractfactory.products.SoftwareEngineerVehicle;
import logica.abstractfactory.products.Tool;
import logica.abstractfactory.products.Vehicle;

/**
 *
 * @author David Bohorquez
 */
public class SoftwareEngineerFactory implements AbstractFactory {

    @Override
    public Tool createTool() {
        return new SoftwareEngineerTool();
    }

    @Override
    public Clothe createClothe() {
        return new SoftwareEngineerClothe();
    }

    @Override
    public Vehicle createVehicle() {
        return new SoftwareEngineerVehicle();
    }

}
