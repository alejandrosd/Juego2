package logica.abstractfactory.factories;

import logica.abstractfactory.products.ElectrialEngineerClothe;
import logica.abstractfactory.products.ElectricalEngineerTool;
import logica.abstractfactory.products.Clothe;
import logica.abstractfactory.products.ElectricalEngineerVehicle;
import logica.abstractfactory.products.Tool;
import logica.abstractfactory.products.Vehicle;

/**
 *
 * @author David Bohorquez
 */
public class ElectricalEngineerFactory implements AbstractFactory {

    @Override
    public Tool createTool() {
        return new ElectricalEngineerTool();
    }

    @Override
    public Clothe createClothe() {
        return new ElectrialEngineerClothe();
    }

    @Override
    public Vehicle createVehicle() {
        return new ElectricalEngineerVehicle();
    }

}
