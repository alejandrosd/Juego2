package logica.abstractfactory.factories;

import logica.abstractfactory.products.Body;
import logica.abstractfactory.products.ElectrialEngineerBody;
import logica.abstractfactory.products.ElectricalEngineerWeapon;
import logica.abstractfactory.products.Weapon;

/**
 *
 * @author David Bohorquez
 */
public class ElectricalEngineerFactory implements AbstractFactory {

    @Override
    public Body createBody() {
        return new ElectrialEngineerBody();
    }

    @Override
    public Weapon createWeapon() {
        return new ElectricalEngineerWeapon();
    }

}
