package logica.abstractfactory.factories;

import logica.abstractfactory.products.ElectrialEngineerClothe;
import logica.abstractfactory.products.ElectricalEngineerTool;
import logica.abstractfactory.products.Clothe;
import logica.abstractfactory.products.ElectricalEngineerVehicle;
import logica.abstractfactory.products.Tool;
import logica.abstractfactory.products.Vehicle;

/**
 *
 * @author David Bohorquez
 */
public class ElectricalEngineerFactory implements AbstractFactory {

    @Override
    public Clothe createBody() {
        return new ElectrialEngineerClothe();
    }

    @Override
    public Tool createWeapon() {
        return new ElectricalEngineerTool();
    }

    @Override
    public Vehicle createVehicle() {
        return new ElectricalEngineerVehicle();
    }

}
