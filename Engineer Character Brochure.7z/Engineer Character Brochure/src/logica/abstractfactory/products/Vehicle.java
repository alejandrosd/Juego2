package logica.abstractfactory.products;

import java.awt.Image;

/**
 *
 * @author David Bohorquez
 */
public interface Vehicle {
    
    public Image operation();
}
