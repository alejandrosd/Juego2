package logica.abstractfactory.products;

import java.awt.Image;

/**
 *
 * @author David Bohorquez
 */
public interface Tool {

    public Image operation();
}
