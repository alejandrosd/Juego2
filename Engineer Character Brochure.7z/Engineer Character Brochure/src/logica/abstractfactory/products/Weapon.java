package logica.abstractfactory.products;

import java.awt.Image;

/**
 *
 * @author David Bohorquez
 */
public interface Weapon {

    public Image operation();
}
